<?php
error_log(file_get_contents("php://input"), 3, "frontend.error");
?>