<?php
 $xml = simplexml_load_file('C:\wamp\www\dashboard\data\Weekly\weekly.xml');
 if($xml) echo json_encode($xml);
?>