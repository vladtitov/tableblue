<?php
/**
 * Created by PhpStorm.
 * User: yrik6
 * Date: 06.06.2016
 * Time: 19:07
 */
error_log(file_get_contents("php://input"), 3, "frontend.error");
?>